
@extends('layouts.app')
@section('title', 'Relatórios')
@section('content')
<div class="container-fluid">
    <h3 class="mt-4 mb-6 text-center">Relatórios</h3>
    
    <div class="row justify-content-around mt-5">
        <div class="col-md-4 ">
            <div class="card">
                <div class="card-body row-justify-content-center">
                    <button class="col btn btn-success btn-lg" data-toggle="modal"
                        data-target="#exampleModalCenter">Relatório de vendas pagas</button>
                        <p class="mt-4 mb-4 "> Total recebido <strong><span class="bg-success ">$ {{$totaldinrec}},00 </span></strong></p>
                </div>
            </div>
        </div>

        <div class="col-md-4 ">
            <div class="card">
                <div class="card-body row-justify-content-center">
                    <button class="col btn btn-primary btn-lg" data-toggle="modal"
                        data-target="#modal3">Relatório de vendas em aberto</button>
                        <p class="mt-4 mb-4 "> Total à receber <strong><span class="bg-primary ">$ {{number_format($totaldinareceber,2, ',','.')}} </span></strong></p>
                </div>
            </div>
        </div>

        <div class="col-md-4  success">
            <div class="card">
                <div class="card-body row-justify-content-center">
                    <button class="col btn btn-danger btn-lg   "  data-toggle="modal"   data-target="#modal2">Relatório de vendas em atraso</button>
                    <p class="mt-4 mb-4 "> Total à receber em atraso <strong><span class="bg-danger ">$ {{number_format($totaldiatrasado,2, ',','.')}} </span></strong></p>
                </div>
            </div>
        </div>

        
    </div>

    

    <!--Modais 1-->
    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">Relatório de vendas  <strong><span class="bg-success ">$ {{number_format($totaldinrec,2, ',','.')}} </span></strong></h5>
                    
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    
                </div>
                <div class="modal-body">
                    <div class="row justify-content-center">
                        <div class="col-12">
                            <table class="table col-12 table-bordered mt-2 table-striped">
                                <thead class="bg-success">
                                    <tr class="text-white">
                                        <th>Nome Cliente</th>
                                        <th>Valor</th>
                                        <th>Data compra</th>
                                        <th>Vencimento</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                  
                                    @foreach($dividasPagas as $paga)
                                   
                                    <tr>
                                      
                                        <td>{{$paga->cliente->nome}}</td>
                                        <td>$ {{$paga->valor}}</td>
                                        <td>{{ \Carbon\Carbon::parse($paga->created_at)->format('d/m/Y H:i:s')  }} </td>
                                        <td>{{ \Carbon\Carbon::parse($paga->data)->format('d/m/Y')  }} </td>
                                        <td>{{$paga->status}}</td>
                                    
                                    </tr>
                                 
                                  
                                    @endforeach
                                    <tr>
                                        <td colspan="100">
                                            @if(count($dividasPagas)==0)
                                            <p class="text-muted text-center"> Não há nenhum registro</p>
                                            @endif
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

     <!--Modais 2-->
     <div class="modal fade" id="modal2" tabindex="-1" role="dialog" aria-labelledby="modal2Title"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle"> Relatório de vendas em atraso  <strong><span class="bg-danger ">$ {{$totaldiatrasado}},00 </span></strong></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body ">
                    <div class="row justify-content-center">
                        <div class="col-12">
                            <table class=" table col-12 table-bordered mt-2 table-striped">
                                <thead class="bg-danger">
                                    <tr class="text-white">
                                        <th>Nome Cliente</th>
                                        <th>Valor</th>
                                        <th>Data compra</th>
                                        <th>Vencimento</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                   @foreach($emAtraso as $atrasada)
                                    <tr>
                                      
                                        <td>{{$atrasada->cliente->nome}}</td>
                                        <td>$ {{$atrasada->valor}}</td>
                                        <td>{{ \Carbon\Carbon::parse($atrasada->created_at)->format('d/m/Y H:i:s')  }} </td>
                                        <td>{{ \Carbon\Carbon::parse($atrasada->data)->format('d/m/Y')  }} </td>
                                        <td>{{$atrasada->status}}</td>
                                    
                                    </tr>
                                  
                                    @endforeach
                                    <tr>
                                        <td colspan="100">
                                            @if(count($emAtraso)==0)
                                            <p class="text-muted text-center"> Não há nenhum registro</p>
                                            @endif
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    <div class="modal fade " id="modal3" tabindex="-1" role="dialog" aria-labelledby="modal2Title"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg " role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle"> Relatório de vendas em aberto  <strong><span class="bg-primary ">$ {{$totaldinareceber}},00 </span></strong></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body ">
                    <div class="row justify-content-center">
                        <div class="col-12">
                            <table class="table col-12 table-bordered mt-2 table-striped ">
                                <thead class="bg-primary">
                                    <tr class="text-white">
                                        <th>Nome Cliente</th>
                                        <th>Valor</th>
                                        <th>Data compra</th>
                                        <th>Vencimento</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                   @foreach($emAberto as $receber)
                                    <tr>
                                      
                                        <td>{{$receber->cliente->nome}}</td>
                                        <td>$ {{$receber->valor}}</td>
                                        <td>{{ \Carbon\Carbon::parse($receber->created_at)->format('d/m/Y H:i:s')  }} </td>
                                        <td>{{ \Carbon\Carbon::parse($receber->data)->format('d/m/Y')  }} </td>
                                        <td>{{$receber->status}}</td>
                                    
                                    </tr>
                                  
                                    @endforeach
                                    <tr>
                                        <td colspan="100">
                                            @if(count($emAberto)==0)
                                            <p class="text-muted text-center"> Não há nenhum registro</p>
                                            @endif
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    </div>





</script>

@endsection