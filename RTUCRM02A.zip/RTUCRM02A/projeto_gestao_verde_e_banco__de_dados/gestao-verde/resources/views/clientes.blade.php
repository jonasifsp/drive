@extends('layouts.app')
@section('title', 'Clientes')

@section('content')
<div class="container-fluid">

<div class="card mb-4 mt-4 ">

                <div class="card-header bg-primary">
                    
                   <h3>{{ $nclientes}} Clientes</h3>
                   
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped " id="dataTable" width="100%" cellspacing="0">
                            <thead>

                                <tr>
                                    <th>Nome</th>
                                    <th>CPF</th>
                                    <th>Celular</th>
                                    <th>E-mail</th>
                                    <th>Endereço</th>
                                    @if(auth()->user()->nivel_id == '1')
                                    <th>Ação</th>
                                    @endif
                                    

                                </tr>
                            </thead>

                            <tbody>
                                @foreach ($clientes as $cliente)
                                    <tr>
                                        <td>{{ $cliente->nome }}</td>
                                        <td>{{ $cliente->cpf }}</td>
                                        <td>{{ $cliente->telefone }}</td>
                                        <td>{{ $cliente->email }}</td>
                                        <td width="250"><span class="font-5 ">{{ $cliente->cidade }}, {{ $cliente->bairro }}, {{ $cliente->rua }}, {{ $cliente->numero }} - CEP {{ $cliente->cep }}</span></td>
                                        @if(auth()->user()->nivel_id == '1')
                                        <td>
                            <form action="{{ route('cliente.destroy', $cliente->id) }}" method="POST">
                                @csrf
                                @method('DELETE')

                                <button class="btn btn-danger " type="submit">APAGAR</button>
                            </form>
                        </td>
                        @endif
                        
                                    </tr>

                                @endforeach
                                @if(count($clientes)==0)
                                    <tr>
                                        <td colspan=100> <p class="text-muted text-center ">Não existe nenhum cliente</p></td>
                                    </tr>
                                    @endif
                            </tbody>
                        </table>
                        {{$pagCliente->links()}}
                    </div>
                </div>
            </div>
    </div>

@endsection