@extends('layouts.app')
@section('title', 'Página não encontrada')
@section('content')
<div class="container-fluid">
    <h3 class="mt-4 mb-4 text-center">Página não encontrada !!!</h3>
    </div>
@endsection
