@extends('layouts.app')
@section('title', 'Erro interno do servidor')
@section('content')
<div class="container-fluid">
    <h3 class="mt-4 mb-4 text-center">Erro interno do servidor !!!</h3>
    </div>
@endsection
