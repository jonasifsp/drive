<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Gestão Verde - @yield('title')</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous">
    </script>
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
    <script src="{{ asset('js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('js/bootstrap2.min.js') }}"></script>
    <script src="{{ asset('js/js3.min.js') }}"></script>
    <link rel="stylesheet" href="{{ asset('css/styles.css') }}">

    <script src="{{ asset('js/scripts.js') }}"></script>

    <script src="{{ asset('js/chart-area-demo.js') }}"></script>
    <script src="{{ asset('js/chart-bar-demo.js') }}"></script>

    <script src="{{ asset('js/datatables-demo.js') }}"></script>



    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link href="{{ asset('img/logo1.png') }}" rel="icon">

</head>

<body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-success">
        <a class="navbar-brand" href="{{ url('/home') }}">
            <img class="mt-4 mb-4 ml-2 mr-4" src="{{ asset('img/logo2.png') }}" alt="logo" height="40px">
        </a>

        <!-- Navbar Search-->
        <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">






        </form>
        <!-- Navbar-->
        <ul class="navbar-nav ml-auto ml-md-0">

            <!-- Authentication Links -->
            @guest
                <li class="nav-item ">
                    <a class="nav-link text-white" href="{{ route('login') }}">{{ __('Entrar') }}</a>
                </li>
                @if (Route::has('register'))
                    <li class="nav-item">
                        <a class="nav-link text-white" href="{{ route('register') }}">{{ __('Novo Colaborador') }}</a>
                    </li>
                @endif
            @else
                <li class="nav-item dropdown">
                    <a id="navbarDropdown" class="nav-link dropdown-toggle text-white" href="#" role="button"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        {{ Auth::user()->name }}
                    </a>

                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="{{ route('logout') }}" onclick="event.preventDefault();
                                                             document.getElementById('logout-form').submit();">
                            {{ __('Sair') }}
                        </a>

                        <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                            @csrf
                        </form>
                    </div>
                </li>
            @endguest

        </ul>
    </nav>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark text-white" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading text-white">Incio</div>
                        <a class="nav-link" href="{{ url('/home') }}">
                            <div class="sb-nav-link-icon text-white"></div>
                            <p> Dashboard </p>
                        </a>
                        <div class="sb-sidenav-menu-heading text-white">Recursos</div>
                        <a class="nav-link" href="{{ url('/anotacoes/index') }}">
                            <div class="sb-nav-link-icon"></div>
                            Anotações

                        </a>





                        
                        <a class="nav-link" href="{{ url('/cliente/create') }}">
                            <div class="sb-nav-link-icon"></div>
                            Cadastro
                            <div class="sb-sidenav-collapse-arrow"></div>
                        </a>
                        <a class="nav-link" href="{{ url('/clientes') }}">
                            <div class="sb-nav-link-icon"></div>
                            Clientes

                        </a>

                        <a class="nav-link" href="{{ url('/dividas') }}">
                            <div class="sb-nav-link-icon"></div>
                            Dívidas
                            <div class="sb-sidenav-collapse-arrow"></div>
                        </a>


                        <a class="nav-link collapsed" href="{{ url('/relatorios/index') }}">
                            <div class="sb-nav-link-icon"></div>
                            Relatórios
                            <div class="sb-sidenav-collapse-arrow"></div>
                        </a>



                        <div class="sb-sidenav-menu-heading"></div>

                        <div class="sb-nav-link-icon"></div>

                        </a>

                        <div class="sb-nav-link-icon"></div>

                        </a>
                    </div>
                </div>
                <div class="sb-sidenav-footer bg-dark">
                    <div class="small">Criado por:</div>
                    Jonas Oliveira
                </div>
            </nav>
        </div>


        <div id="layoutSidenav_content">
    
                <div class="justify-content-center">
                    @if (Session::get('success'))
                        <div class="alert col-md-10 alert-success alert-dismissible fade show" role="alert">
                            {{ Session::get('success') }}
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        
                    @endif
                    @if (Session::get('warning'))
                        <div class="alert col-md-8 alert-warning alert-dismissible fade show" role="alert">
                            {{ Session::get('warning') }}
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    @endif
                    @if (Session::get('error'))
                        <div class="alert col-md-10 alert-danger alert-dismissible fade show" role="alert">
                            {{ Session::get('error') }}
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    @endif
                </div>
                @if ($errors->any())
                    <div class="row justify-content-center">
                        @foreach ($errors->all() as $error)
                            <div class="alert col-md-10 alert-danger alert-dismissible fade show" role="alert">

                                <ul>

                                    <li>{{ $error }}</li>

                                </ul>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        @endforeach
                    </div>

                @endif
            

            @yield('content')



            <footer class="py-4 bg-light mt-auto">
                <div class="container-fluid">
                    <div class="d-flex align-items-center justify-content-between small">
                        <div class="text-muted">Copyright &copy; Gestão Verde 2021</div>
                        <div>
                            <a href="#">Privacidade</a>
                            &middot;
                            <a href="#">Termos &amp; Condições</a>
                        </div>
                    </div>
                </div>
            </footer>




</body>

</html>
