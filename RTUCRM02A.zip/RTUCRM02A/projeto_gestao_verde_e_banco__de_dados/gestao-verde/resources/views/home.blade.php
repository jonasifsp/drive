@extends('layouts.app')
@section('title', 'Dashboard')

@section('content')

    <main>

        <div class="container-fluid">
        <h3 class="mt-4 mb-4 ">Avisos</h3>
        <div class="row mb-5">
        <div class="col-5">
        
        

        @if($divDia>0)
        <p class="text-success ">Existem <strong>{{$divDia}}</strong> dívida(as) que vencem <strong>hoje</strong> !  </p>
         @else
        <p class="text-success "><strong>Não</strong> existem dívidas que vencem <strong>hoje</strong> ! </p>
        @endif

        @if($divAberto>0)
        <p class="text-primary ">Existem <strong>{{$divAberto}}</strong> dívida(as) <strong>Em Aberto </strong> ! </p>
        @else
        <p class="text-primary ">Não Existe dívidas <strong>Em Aberto </strong> ! </p>
        @endif

        @if($divAtraso>0)
        <p class="text-danger ">Existem <strong>{{$divAtraso}}</strong> dívida(as) em atraso !  </p>
         @else
        <p class="text-danger " >Não existem dívidas <strong>Em Atraso</strong> ! </p>
        @endif

        </div>


        <div class="col-2">
        <img class="" src="{{ asset('img/logo1.png') }}" alt="logo" height="130px">
        </div>
        <div class="col-5">
        <p class=" mb-3 text-right"> Total recebido <strong><span class="bg-success ">$ {{number_format($totaldinrec,2, ',','.')}}  </span></strong></p>
        <p class=" mb-3 text-right "> Total à receber <strong><span class="bg-primary ">$ {{number_format($totaldinareceber,2, ',','.')}}  </span></strong></p>
        <p class=" mb-3 text-right"> Total à receber em atraso <strong><span class="bg-danger ">$ {{number_format($totaldiatrasado,2, ',','.')}} </span></strong></p>
            </div></div>
            <h3 class="mt-2 mb-4">Anotações</h3>
            


            <div class="row mb-5">

                @foreach ($notas as $nota)

                    <div class="col-lg-3 col-md-6 col-sm-12">
                        <div class="card bg-success text-white mb-4">
                            <div class="card-body">
                                <h5>{{ $nota->title }}</h5>
                            </div>
                            <div class="card-footer d-flex align-items-center justify-content-between">
                                <p>{{ $nota->descricao }}</p>

                            </div>
                        </div>
                    </div>
                @endforeach

                @if(count($notas)==0)
                                    
                <p class="text-center mt-4 mb-4 mr-4 ml-4"> Ainda não existe nenhuma anotação, <a href="{{ url('/anotacoes/index') }}"> Clique aqui para adicionar</a> </p>
                                    
                @endif
                
            </div>

            



            <div class="card mb-4 ">
                <div class="card-header bg-success">
                    <h3>{{$ndividas}} Vendas  </h3> 

                    
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped" id="dataTable" width="100%" cellspacing="0">
                            <thead>

                                <tr>
                                    <th>Nome</th>
                                    <th>Valor</th>
                                    <th>Vencimento</th>
                                    <th>Data da compra</th>
                                    <th>Status</th>

                                    @if(auth()->user()->nivel_id == '1')
                                    <th>Ação</th>
                                    @endif
                                </tr>
                            </thead>

                            <tbody>

                                @foreach ($dividas as $divida)
                                
                                    <tr>
                                        <td>{{ $divida->cliente->nome }}</td>
                                        
                                        <td>${{ $divida->valor }}</td>
                                        <td>{{ \Carbon\Carbon::parse($divida->data)->format('d/m/Y')  }}</td>
                                        <td>{{ \Carbon\Carbon::parse($divida->created_at)->format('d/m/Y  H:i:s')  }}</td>
                                        <td>{{ $divida->status }}</td>

                                        @if(auth()->user()->nivel_id == '1')
                                        <td>
                            <form action="{{ route('divida.destroy', $divida->id) }}" method="POST">
                                @csrf
                                @method('DELETE')

                                <button class="btn btn-danger " type="submit">APAGAR</button>
                            </form>
                        </td>
                        @endif
                                    </tr>

                                @endforeach
                                @if(count($dividas)==0)
                                    <tr>
                                        <td colspan=100> <p class="text-muted text-center">Não existe nenhuma venda</p></td>
                                    </tr>
                                    @endif
                            </tbody>
                        </table>
                        
                       
                    </div>
                    {{$pag->links()}}
                </div>
            </div>

            

                 @if(auth()->user()->nivel_id == '1')
                <h5 class="mt-5 mb-4 text-center">Exporte e importe as vendas para planilhas excel</h5>    
    
    <div class="row">
            
        <div class="col-lg-6 col-md-6 col-sm-6 mt-4 mb-4">
            <div class="card">
                <div class="card-header bg-dark text-white">
                    Exportação
                </div>
                <div class="card-body">

                    <div class="row align-items-end">

                        <div class="col-8 col-sm-8 mt-4 mb-4">
                            <label>Exportar todas as vendas.    <strong>     vendas.xlsx</strong></label>
                            
                        </div><br><br>
                        <div class="col-4 col-sm-4 mt-4 mb-4">
                            <a href="{{ route('export') }}" class="btn btn-success">Exportar</a>
                        </div>
                        
                    </div>
                    
                </div>
                <div class="card-footer ">
                        <form action="{{ route('cliente.export') }}" method="get" id="form2">
                        @csrf
                        <label class="mt-4"> Exportar vendas de um cliente </label>
                        <select name="id" class="form-control mt-4 " id="id">
                                        <option value="0">Selecione um Cliente </option>
                                        @foreach($clientes as $cliente)
                                        <option value="{{$cliente->id}}">{{$cliente->nome}}</option>
                                        @endforeach
                                    </select>
                                   
                                    <button type="submit" class="btn btn-success mt-4 mb-4 text-right">Exportar</button>
                                   
                                    </div>
                                    </form>
            </div>
        </div>

        <div class="col-lg-6 col-md-6 col-sm-6 mt-4 mb-4">

            <form action="{{ route('import') }}" method="post" enctype="multipart/form-data">
                <div class="card">
                    <div class="card-header bg-dark text-white">
                        Importar 
                    </div>
                    <div class="card-body">
                        <div class="col-12">

                            @csrf
                            <div class="form-group">
                                <input name="file" type="file" class="custom-file-input" id="file-input">
                                <label class="custom-file-label" for="file-input" data-browse="Procurar">
                                    Procurar
                                </label>
                            </div>

                        </div>
                    </div>
                    <div class="card-footer text-right">
                        <button type="submit" class="btn btn-success">Importar</button>
                    </div>

                </div>

            </form>

        </div>
        @else
        
                <h5 class="mt-5 mb-5 text-center">Você não tem permissão para Exportar e Importar vendas</h5>

                
        @endif

        </div>
        
    </main>



@endsection
