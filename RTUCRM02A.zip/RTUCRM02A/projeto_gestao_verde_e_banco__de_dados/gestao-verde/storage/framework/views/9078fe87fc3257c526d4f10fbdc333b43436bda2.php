
    
    <?php $__env->startSection('title', 'Cadastro'); ?>
     
<?php $__env->startSection("content"); ?>

<div class="container-fluid">
                        <h3 class="mt-4 mb-4 text-center">Cadastrar cliente</h3>
<div class="container">
    <div class="row">
        <p class="divMensage alert alert-warning"></p>
    </div>
<form id="form" action="/cliente" method="POST">
    <?php echo csrf_field(); ?>
    <?php if(isset($cliente)): ?>
    <?php echo method_field('PUT'); ?>
    <?php endif; ?>
   

    <div class="row mt-4 mb-4">
        <div class="col-10">
            <div class="form-group">
                <p><strong>Informações</strong></p>
                <br><br>
            <label> Nome </label>
            <input type="text" id ="nome" name ='nome' class="form-control" required>
            </div>
        </div>
        

        <div class="col-12 col-sm-4">
            <div class="form-group">
            <label>Email</label>
            <input type="email" id = "email" name="email" class="form-control" required>
            </div>
        </div>

        
            <div class="col-12 col-sm-3">
            <div class="form-group">
            <label> CPF </label>
            <input type="text" id ="cpf" name="cpf" class="form-control" required>
            </div>
            
            </div>
           
    <div class="col-12 col-sm-3">
    <div class="form-group">
    <label for="">Celular</label>
    <input type="text" name ="telefone" id="telefone" class="form-control" required>
    
    </div> </div>
   
            
            </div>

            

            <br><br>



            <p><strong>Endereço</strong> </p>
            <br><br>
        <div class="row mt-2">
        <div class="col-12 col-sm-2">
            <div class="form-group">
            <label> CEP </label>
            <input type="text" name ="cep" id="cep" class="form-control" required>
            </div>
        </div>


        <div class="col-12 col-sm-4">
            <div class="form-group">
            <label> Cidade </label>
            <input type="text" id="cidade" name ="cidade" class="form-control" required>
            </div>
        </div>

        

        <div class="col-12 col-sm-3">
            <div class="form-group">
            <label> Bairro </label>
            <input type="text" id="bairro" name ="bairro" class="form-control" required>
            </div>
        </div>
       
       

        <div class="col-12 col-sm-7">
            <div class="form-group">
            <label> Logradouro </label>
            <input type="text" id="rua" name ="rua" class="form-control" required>
            </div>
        </div>

        <div class="col-12 col-sm-2">
            <div class="form-group">
            <label> Número </label>
            <input type="text" id="numero" name ="numero" class="form-control" required>
            </div>
        </div>

      </div>

    


    

    <button type="submit" class="btn btn-success mt-20 mt-5 mb-5" id ="btnCadastrar">Cadastrar</button>
   
    </div>  

    </div>

<br><br>
<script src="<?php echo e(asset('js/jquery.mask.js')); ?>"></script>
<script>


 



    $(document).ready(function(){
        $("#cep").mask("00000-000")
        $("#cpf").mask("000.000.000-00")
        $("#telefone").mask("(00) 00000-0000")

        $("#cep").blur(function(){
            
            var cep = $(this).unmask().val()
           
           $.ajax({
               url:"https://viacep.com.br/ws/"+cep+"/json",
               type:"GET",
             
           }).done(function(data){
            console.log("Ok:", data)
            $("#rua").val(data.logradouro),
            $("#cidade").val(data.localidade)
            $("#bairro").val(data.bairro)
           }).fail(function(){
               console.log("erro")
           }).always(function(){

           })
        })

      $('.divMensage').hide()
        
        $("#btnCadastrar").click(function(e){
            $('.divMensage').html = "";
            var elemento = document.getElementsByClassName('divMensage')
    


        
            var validaEmail =  /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
            var email = $("#email").val();

            var validaCpf = /^\d{3}\.\d{3}\.\d{3}\-\d{2}$/;
            var cpf = $("#cpf").val();
            var nome = $("#nome").val();
            var telefone = $("#telefone").val();
            var cep = $("#cep").val();
            var cidade = $("#cidade").val();
            var rua = $("#rua").val();
            var bairro = $("#bairro").val();
            var numero = $("#numero").val();
            e.preventDefault()
            if(nome==""){
                
                $('.divMensage').html(' Infome o nome')
                
                $('.divMensage').fadeIn('slow')
                
                
                
            }else if(!validaEmail.test(email)){
                $('.divMensage').html(' Email Invalido')
                $('.divMensage').fadeIn('slow')

            }else if(!validaCpf.test(cpf)){
                $('.divMensage').html(' CPF Invalido')
                $('.divMensage').fadeIn('slow')
            }
            else if(telefone==""){
                $('.divMensage').html(' Infome o Celular')
                $('.divMensage').fadeIn('slow')
            }else if(cep==""){
                $('.divMensage').html(' Infome o CEP')
                $('.divMensage').fadeIn('slow')
            }else if(cidade==""){
                $('.divMensage').html(' Infome o Cidade')
                $('.divMensage').fadeIn('slow')
            }else if(bairro==""){
                $('.divMensage').html(' Infome o Bairro')
                $('.divMensage').fadeIn('slow')
              
            }
            else if(rua==""){
                $('.divMensage').html(' Infome o Rua')
                $('.divMensage').fadeIn('slow')
            }
            else if(numero==""){
                $('.divMensage').html(' Infome o numero da casa')
                $('.divMensage').fadeIn('slow')
            }
            
            else{
                $('#form').submit()
            }
        })
        
       
    })
</script>
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gestao-verde\gestao-verde\resources\views/create.blade.php ENDPATH**/ ?>