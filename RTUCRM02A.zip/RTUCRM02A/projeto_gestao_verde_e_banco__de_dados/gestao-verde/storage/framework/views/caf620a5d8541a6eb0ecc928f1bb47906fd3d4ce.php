<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Gestão Verde - <?php echo $__env->yieldContent('title'); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous">
    </script>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/js3.min.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">

    <script src="<?php echo e(asset('js/scripts.js')); ?>"></script>

    <script src="<?php echo e(asset('js/chart-area-demo.js')); ?>"></script>
    <script src="<?php echo e(asset('js/chart-bar-demo.js')); ?>"></script>

    <script src="<?php echo e(asset('js/datatables-demo.js')); ?>"></script>



    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('img/logo1.png')); ?>" rel="icon">

</head>

<body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-success">
        <a class="navbar-brand" href="<?php echo e(url('/home')); ?>">
            <img class="mt-4 mb-4 ml-4 mr-4" src="<?php echo e(asset('img/logo2.png')); ?>" alt="logo" height="40px">
        </a>

        <!-- Navbar Search-->
        <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">






        </form>
        <!-- Navbar-->
        <ul class="navbar-nav ml-auto ml-md-0">

            <!-- Authentication Links -->
            <?php if(auth()->guard()->guest()): ?>
                <li class="nav-item ">
                    <a class="nav-link text-white" href="<?php echo e(route('login')); ?>"><?php echo e(__('Entrar')); ?></a>
                </li>
                <?php if(Route::has('register')): ?>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="<?php echo e(route('register')); ?>"><?php echo e(__('Novo Colaborador')); ?></a>
                    </li>
                <?php endif; ?>
            <?php else: ?>
                <li class="nav-item dropdown">
                    <a id="navbarDropdown" class="nav-link dropdown-toggle text-white" href="#" role="button"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        <?php echo e(Auth::user()->name); ?>

                    </a>

                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                             document.getElementById('logout-form').submit();">
                            <?php echo e(__('Sair')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </li>
            <?php endif; ?>

        </ul>
    </nav>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark text-white" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading text-white">Incio</div>
                        <a class="nav-link" href="<?php echo e(url('/home')); ?>">
                            <div class="sb-nav-link-icon text-white"></div>
                            <p> Dashboard </p>
                        </a>
                        <div class="sb-sidenav-menu-heading text-white">Recursos</div>
                        <a class="nav-link" href="<?php echo e(url('/cliente/create')); ?>">
                            <div class="sb-nav-link-icon"></div>
                            Cadastro

                        </a>





                        <a class="nav-link" href="<?php echo e(url('/anotacoes/index')); ?>">
                            <div class="sb-nav-link-icon"></div>
                            Anotações
                            <div class="sb-sidenav-collapse-arrow"></div>
                        </a>

                        <a class="nav-link" href="<?php echo e(url('/dividas')); ?>">
                            <div class="sb-nav-link-icon"></div>
                            Dívidas
                            <div class="sb-sidenav-collapse-arrow"></div>
                        </a>


                        <a class="nav-link collapsed" href="<?php echo e(url('/relatorios/index')); ?>">
                            <div class="sb-nav-link-icon"></div>
                            Relatórios
                            <div class="sb-sidenav-collapse-arrow"></div>
                        </a>



                        <div class="sb-sidenav-menu-heading"></div>

                        <div class="sb-nav-link-icon"></div>

                        </a>

                        <div class="sb-nav-link-icon"></div>

                        </a>
                    </div>
                </div>
                <div class="sb-sidenav-footer bg-dark">
                    <div class="small">Criado por:</div>
                    Jonas Oliveira
                </div>
            </nav>
        </div>


        <div id="layoutSidenav_content">
    
                <div class="row justify-content-center">
                    <?php if(Session::get('success')): ?>
                        <div class="alert col-md-10 alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(Session::get('success')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        
                    <?php endif; ?>
                    <?php if(Session::get('warning')): ?>
                        <div class="alert col-md-10 alert-warning alert-dismissible fade show" role="alert">
                            <?php echo e(Session::get('warning')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                    <?php if(Session::get('error')): ?>
                        <div class="alert col-md-10 alert-danger alert-dismissible fade show" role="alert">
                            <?php echo e(Session::get('error')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
                <?php if($errors->any()): ?>
                    <div class="row justify-content-center">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert col-md-10 alert-danger alert-dismissible fade show" role="alert">

                                <ul>

                                    <li><?php echo e($error); ?></li>

                                </ul>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                <?php endif; ?>
            

            <?php echo $__env->yieldContent('content'); ?>



            <footer class="py-4 bg-light mt-auto">
                <div class="container-fluid">
                    <div class="d-flex align-items-center justify-content-between small">
                        <div class="text-muted">Copyright &copy; Gestão Verde 2021</div>
                        <div>
                            <a href="#">Privacidade</a>
                            &middot;
                            <a href="#">Termos &amp; Condições</a>
                        </div>
                    </div>
                </div>
            </footer>




</body>

</html>
<?php /**PATH C:\xampp\htdocs\gestao-verde\resources\views/layouts/app.blade.php ENDPATH**/ ?>