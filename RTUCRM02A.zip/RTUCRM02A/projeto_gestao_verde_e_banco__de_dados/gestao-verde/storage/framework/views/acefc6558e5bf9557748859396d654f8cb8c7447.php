
<?php $__env->startSection('title', 'Página não encontrada'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h3 class="mt-4 mb-4 text-center">Página não encontrada !!!</h3>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gestao-verde\gestao-verde\resources\views/errors/404.blade.php ENDPATH**/ ?>