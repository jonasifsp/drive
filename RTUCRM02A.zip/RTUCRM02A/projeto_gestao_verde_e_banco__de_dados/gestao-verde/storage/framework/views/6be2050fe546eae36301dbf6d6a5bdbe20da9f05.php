<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <title>Cadastro de cliente</title>
</head>
<body>
<div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-success shadow-sm">
            <div class="container">
                <a class="navbar-brand text-white" href="<?php echo e(url('/')); ?>">
                  Gestão Verde
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto ">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item ">
                                <a class="nav-link text-white" href="<?php echo e(route('login')); ?>"><?php echo e(__('Entrar')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link text-white" href="<?php echo e(route('register')); ?>"><?php echo e(__('Novo Colaborador')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle text-white" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
     






<div class="container">
<form action="">
<br><br>
    <div class="row">
        <div class="col-12">
            <div class="form-group">
            <label> Nome </label>
            <input type="text" class="form-control">
            </div>
        </div>
        

        <div class="col-12 col-sm-4">
            <div class="form-group">
            <label> Email </label>
            <input type="email" class="form-control">
            </div>
        </div>

        
            <div class="col-12 col-sm-3">
            <div class="form-group">
            <label> CPF </label>
            <input type="text" class="form-control">
            </div>
            </div>
            
            </div>
            <br><br>



            <p><strong>Endereço</strong> </p>
        <div class="row mt-2">
        <div class="col-12 col-sm-2">
            <div class="form-group">
            <label> CEP </label>
            <input type="text" class="form-control">
            </div>
        </div>


        <div class="col-12 col-sm-5">
            <div class="form-group">
            <label> Cidade </label>
            <input type="text" class="form-control">
            </div>
        </div>

        

        <div class="col-12 col-sm-4">
            <div class="form-group">
            <label> Bairro </label>
            <input type="text" class="form-control">
            </div>
        </div>
       
       

        <div class="col-12 col-sm-7">
            <div class="form-group">
            <label> Logradouro </label>
            <input type="text" class="form-control">
            </div>
        </div>

        <div class="col-12 col-sm-1">
            <div class="form-group">
            <label> Numero </label>
            <input type="text" class="form-control">
            </div>
        </div>

      </div>

    <div class="row mt-4">
    <div class="col-12">
    <h6>Telefones</h6>
 
    <hr>
    
    </div>


    </div>


    <div class="row mt-2">
    <div class="col-12">
    <div class="row align-items-center">
    <div class="col-12 col-sm-4">
    <div class="form-group">
    <label for="">Telefone</label>
    <input type="text" class="form-control">
    
    </div> </div>
   </div> </div> </div>

    <button type="submit" class="btn btn-success">Cadastrar</button>

        



<br><br>
        
</body>
</html><?php /**PATH C:\xampp\htdocs\gestao-verde\gestao-verde\gestao-verde\resources\views/create.blade.php ENDPATH**/ ?>