<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

    <main>

        <div class="container-fluid">
            <h3 class="mt-4 mb-4">Dashboard</h3>



            <div class="row">

                <?php $__currentLoopData = $notas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-lg-3 col-md-6 col-sm-12">
                        <div class="card bg-success text-white mb-4">
                            <div class="card-body">
                                <h3><?php echo e($nota->title); ?></h3>
                            </div>
                            <div class="card-footer d-flex align-items-center justify-content-between">
                                <p><?php echo e($nota->descricao); ?></p>

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-table mr-1"></i>
                    Clientes
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>

                                <tr>
                                    <th>Nome</th>
                                    <th>CPF</th>
                                    <th>Celular</th>
                                    <th>E-mail</th>
                                    

                                </tr>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($cliente->nome); ?></td>
                                        <td><?php echo e($cliente->cpf); ?></td>
                                        <td><?php echo e($cliente->telefone); ?></td>
                                        <td><?php echo e($cliente->email); ?></td>
                                        

                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>



            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-table mr-1"></i>
                    Clientes
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>

                                <tr>
                                    <th>Nome</th>
                                    <th>CPF</th>
                                    <th>Celular</th>
                                    <th>E-mail</th>
                                    <th>Status</th>

                                </tr>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $dividas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $divida): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($divida->cliente->nome); ?></td>
                                        <td><?php echo e($divida->data); ?></td>
                                        <td><?php echo e($divida->valor); ?></td>
                                        <td><?php echo e($divida->created_at); ?></td>
                                        <td><?php echo e($divida->status); ?></td>

                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>





        <div class="col-12">
            <div class="card">
                <div class="card-header bg-dark text-white">
                    Exportação
                </div>
                <div class="card-body">

                    <div class="row align-items-end">

                        <div class="col-12 col-sm-3">
                            <label>Tipo de arquivo de exportação</label>
                            <select class="form-control" name="export_file_type">
                                <option value="csv">CSV</option>
                                <option value="xls">XLS</option>
                            </select>
                        </div>
                        <div class="col-12 col-sm-3">
                            <a href="<?php echo e(route('export')); ?>" class="btn btn-success">Exportar</a>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-12 mt-4 mb-4">

            <form action="<?php echo e(route('import')); ?>" method="post" enctype="multipart/form-data">
                <div class="card">
                    <div class="card-header bg-dark text-white">
                        Importar arquivo CSV
                    </div>
                    <div class="card-body">
                        <div class="col-12">

                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <input name="file" type="file" class="custom-file-input" id="file-input">
                                <label class="custom-file-label" for="file-input" data-browse="Procurar">
                                    Procurar
                                </label>
                            </div>

                        </div>
                    </div>
                    <div class="card-footer text-right">
                        <button type="submit" class="btn btn-success">Importar</button>
                    </div>

                </div>

            </form>

        </div>
    </main>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gestao-verde\resources\views/home.blade.php ENDPATH**/ ?>