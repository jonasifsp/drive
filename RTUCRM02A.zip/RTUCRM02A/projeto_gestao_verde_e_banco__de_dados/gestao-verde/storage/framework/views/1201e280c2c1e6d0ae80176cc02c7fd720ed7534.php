<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\gestao-verde\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>