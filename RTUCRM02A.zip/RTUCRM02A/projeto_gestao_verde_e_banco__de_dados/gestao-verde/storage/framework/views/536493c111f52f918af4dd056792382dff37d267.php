

<?php $__env->startSection('title', 'Relatórios'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h3 class="mt-4 mb-6 text-center">Relatórios</h3>
    
    <div class="row justify-content-around mt-5">
        <div class="col-md-4 ">
            <div class="card">
                <div class="card-body row-justify-content-center">
                    <button class="col btn btn-success btn-lg" data-toggle="modal"
                        data-target="#exampleModalCenter">Relatório de vendas pagas</button>
                        <p class="mt-4 mb-4 "> Total recebido <strong><span class="bg-success ">$ <?php echo e($totaldinrec); ?>,00 </span></strong></p>
                </div>
            </div>
        </div>

        <div class="col-md-4 ">
            <div class="card">
                <div class="card-body row-justify-content-center">
                    <button class="col btn btn-primary btn-lg" data-toggle="modal"
                        data-target="#modal3">Relatório de vendas em aberto</button>
                        <p class="mt-4 mb-4 "> Total à receber <strong><span class="bg-primary ">$ <?php echo e(number_format($totaldinareceber,2, ',','.')); ?> </span></strong></p>
                </div>
            </div>
        </div>

        <div class="col-md-4  success">
            <div class="card">
                <div class="card-body row-justify-content-center">
                    <button class="col btn btn-danger btn-lg   "  data-toggle="modal"   data-target="#modal2">Relatório de vendas em atraso</button>
                    <p class="mt-4 mb-4 "> Total à receber em atraso <strong><span class="bg-danger ">$ <?php echo e(number_format($totaldiatrasado,2, ',','.')); ?> </span></strong></p>
                </div>
            </div>
        </div>

        
    </div>

    

    <!--Modais 1-->
    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">Relatório de vendas  <strong><span class="bg-success ">$ <?php echo e(number_format($totaldinrec,2, ',','.')); ?> </span></strong></h5>
                    
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    
                </div>
                <div class="modal-body">
                    <div class="row justify-content-center">
                        <div class="col-12">
                            <table class="table col-12 table-bordered mt-2 table-striped">
                                <thead class="bg-success">
                                    <tr class="text-white">
                                        <th>Nome Cliente</th>
                                        <th>Valor</th>
                                        <th>Data compra</th>
                                        <th>Vencimento</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                  
                                    <?php $__currentLoopData = $dividasPagas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   
                                    <tr>
                                      
                                        <td><?php echo e($paga->cliente->nome); ?></td>
                                        <td>$ <?php echo e($paga->valor); ?></td>
                                        <td><?php echo e(\Carbon\Carbon::parse($paga->created_at)->format('d/m/Y H:i:s')); ?> </td>
                                        <td><?php echo e(\Carbon\Carbon::parse($paga->data)->format('d/m/Y')); ?> </td>
                                        <td><?php echo e($paga->status); ?></td>
                                    
                                    </tr>
                                 
                                  
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td colspan="100">
                                            <?php if(count($dividasPagas)==0): ?>
                                            <p class="text-muted text-center"> Não há nenhum registro</p>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

     <!--Modais 2-->
     <div class="modal fade" id="modal2" tabindex="-1" role="dialog" aria-labelledby="modal2Title"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle"> Relatório de vendas em atraso  <strong><span class="bg-danger ">$ <?php echo e($totaldiatrasado); ?>,00 </span></strong></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body ">
                    <div class="row justify-content-center">
                        <div class="col-12">
                            <table class=" table col-12 table-bordered mt-2 table-striped">
                                <thead class="bg-danger">
                                    <tr class="text-white">
                                        <th>Nome Cliente</th>
                                        <th>Valor</th>
                                        <th>Data compra</th>
                                        <th>Vencimento</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                   <?php $__currentLoopData = $emAtraso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atrasada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                      
                                        <td><?php echo e($atrasada->cliente->nome); ?></td>
                                        <td>$ <?php echo e($atrasada->valor); ?></td>
                                        <td><?php echo e(\Carbon\Carbon::parse($atrasada->created_at)->format('d/m/Y H:i:s')); ?> </td>
                                        <td><?php echo e(\Carbon\Carbon::parse($atrasada->data)->format('d/m/Y')); ?> </td>
                                        <td><?php echo e($atrasada->status); ?></td>
                                    
                                    </tr>
                                  
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td colspan="100">
                                            <?php if(count($emAtraso)==0): ?>
                                            <p class="text-muted text-center"> Não há nenhum registro</p>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    <div class="modal fade " id="modal3" tabindex="-1" role="dialog" aria-labelledby="modal2Title"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg " role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle"> Relatório de vendas em aberto  <strong><span class="bg-primary ">$ <?php echo e($totaldinareceber); ?>,00 </span></strong></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body ">
                    <div class="row justify-content-center">
                        <div class="col-12">
                            <table class="table col-12 table-bordered mt-2 table-striped ">
                                <thead class="bg-primary">
                                    <tr class="text-white">
                                        <th>Nome Cliente</th>
                                        <th>Valor</th>
                                        <th>Data compra</th>
                                        <th>Vencimento</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                   <?php $__currentLoopData = $emAberto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                      
                                        <td><?php echo e($receber->cliente->nome); ?></td>
                                        <td>$ <?php echo e($receber->valor); ?></td>
                                        <td><?php echo e(\Carbon\Carbon::parse($receber->created_at)->format('d/m/Y H:i:s')); ?> </td>
                                        <td><?php echo e(\Carbon\Carbon::parse($receber->data)->format('d/m/Y')); ?> </td>
                                        <td><?php echo e($receber->status); ?></td>
                                    
                                    </tr>
                                  
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td colspan="100">
                                            <?php if(count($emAberto)==0): ?>
                                            <p class="text-muted text-center"> Não há nenhum registro</p>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    </div>





</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gestao-verde\gestao-verde\resources\views/relatorios/index.blade.php ENDPATH**/ ?>