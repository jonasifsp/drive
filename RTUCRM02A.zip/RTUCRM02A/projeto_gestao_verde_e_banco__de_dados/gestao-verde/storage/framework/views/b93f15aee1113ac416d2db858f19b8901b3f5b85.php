<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

    <main>

        <div class="container-fluid">
        <h3 class="mt-4 mb-4 ">Avisos</h3>
        <div class="row mb-5">
        <div class="col-5">
        
        

        <?php if($divDia>0): ?>
        <p class="text-success ">Existem <strong><?php echo e($divDia); ?></strong> dívida(as) que vencem <strong>hoje</strong> !  </p>
         <?php else: ?>
        <p class="text-success "><strong>Não</strong> existem dívidas que vencem <strong>hoje</strong> ! </p>
        <?php endif; ?>

        <?php if($divAberto>0): ?>
        <p class="text-primary ">Existem <strong><?php echo e($divAberto); ?></strong> dívida(as) <strong>Em Aberto </strong> ! </p>
        <?php else: ?>
        <p class="text-primary ">Não Existe dívidas <strong>Em Aberto </strong> ! </p>
        <?php endif; ?>

        <?php if($divAtraso>0): ?>
        <p class="text-danger ">Existem <strong><?php echo e($divAtraso); ?></strong> dívida(as) em atraso !  </p>
         <?php else: ?>
        <p class="text-danger " >Não existem dívidas <strong>Em Atraso</strong> ! </p>
        <?php endif; ?>

        </div>


        <div class="col-2">
        <img class="" src="<?php echo e(asset('img/logo1.png')); ?>" alt="logo" height="130px">
        </div>
        <div class="col-5">
        <p class=" mb-3 text-right"> Total recebido <strong><span class="bg-success ">$ <?php echo e(number_format($totaldinrec,2, ',','.')); ?>  </span></strong></p>
        <p class=" mb-3 text-right "> Total à receber <strong><span class="bg-primary ">$ <?php echo e(number_format($totaldinareceber,2, ',','.')); ?>  </span></strong></p>
        <p class=" mb-3 text-right"> Total à receber em atraso <strong><span class="bg-danger ">$ <?php echo e(number_format($totaldiatrasado,2, ',','.')); ?> </span></strong></p>
            </div></div>
            <h3 class="mt-2 mb-4">Anotações</h3>
            


            <div class="row mb-5">

                <?php $__currentLoopData = $notas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-lg-3 col-md-6 col-sm-12">
                        <div class="card bg-success text-white mb-4">
                            <div class="card-body">
                                <h5><?php echo e($nota->title); ?></h5>
                            </div>
                            <div class="card-footer d-flex align-items-center justify-content-between">
                                <p><?php echo e($nota->descricao); ?></p>

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if(count($notas)==0): ?>
                                    
                <p class="text-center mt-4 mb-4 mr-4 ml-4"> Ainda não existe nenhuma anotação, <a href="<?php echo e(url('/anotacoes/index')); ?>"> Clique aqui para adicionar</a> </p>
                                    
                <?php endif; ?>
                
            </div>

            



            <div class="card mb-4 ">
                <div class="card-header bg-success">
                    <h3><?php echo e($ndividas); ?> Vendas  </h3> 

                    
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped" id="dataTable" width="100%" cellspacing="0">
                            <thead>

                                <tr>
                                    <th>Nome</th>
                                    <th>Valor</th>
                                    <th>Vencimento</th>
                                    <th>Data da compra</th>
                                    <th>Status</th>

                                    <?php if(auth()->user()->nivel_id == '1'): ?>
                                    <th>Ação</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>

                            <tbody>

                                <?php $__currentLoopData = $dividas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $divida): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                    <tr>
                                        <td><?php echo e($divida->cliente->nome); ?></td>
                                        
                                        <td>$<?php echo e($divida->valor); ?></td>
                                        <td><?php echo e(\Carbon\Carbon::parse($divida->data)->format('d/m/Y')); ?></td>
                                        <td><?php echo e(\Carbon\Carbon::parse($divida->created_at)->format('d/m/Y  H:i:s')); ?></td>
                                        <td><?php echo e($divida->status); ?></td>

                                        <?php if(auth()->user()->nivel_id == '1'): ?>
                                        <td>
                            <form action="<?php echo e(route('divida.destroy', $divida->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                                <button class="btn btn-danger " type="submit">APAGAR</button>
                            </form>
                        </td>
                        <?php endif; ?>
                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if(count($dividas)==0): ?>
                                    <tr>
                                        <td colspan=100> <p class="text-muted text-center">Não existe nenhuma venda</p></td>
                                    </tr>
                                    <?php endif; ?>
                            </tbody>
                        </table>
                        
                       
                    </div>
                    <?php echo e($pag->links()); ?>

                </div>
            </div>

            

                 <?php if(auth()->user()->nivel_id == '1'): ?>
                <h5 class="mt-5 mb-4 text-center">Exporte e importe as vendas para planilhas excel</h5>    
    
    <div class="row">
            
        <div class="col-lg-6 col-md-6 col-sm-6 mt-4 mb-4">
            <div class="card">
                <div class="card-header bg-dark text-white">
                    Exportação
                </div>
                <div class="card-body">

                    <div class="row align-items-end">

                        <div class="col-8 col-sm-8 mt-4 mb-4">
                            <label>Exportar todas as vendas.    <strong>     vendas.xlsx</strong></label>
                            
                        </div><br><br>
                        <div class="col-4 col-sm-4 mt-4 mb-4">
                            <a href="<?php echo e(route('export')); ?>" class="btn btn-success">Exportar</a>
                        </div>
                        
                    </div>
                    
                </div>
                <div class="card-footer ">
                        <form action="<?php echo e(route('cliente.export')); ?>" method="get" id="form2">
                        <?php echo csrf_field(); ?>
                        <label class="mt-4"> Exportar vendas de um cliente </label>
                        <select name="id" class="form-control mt-4 " id="id">
                                        <option value="0">Selecione um Cliente </option>
                                        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($cliente->id); ?>"><?php echo e($cliente->nome); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                   
                                    <button type="submit" class="btn btn-success mt-4 mb-4 text-right">Exportar</button>
                                   
                                    </div>
                                    </form>
            </div>
        </div>

        <div class="col-lg-6 col-md-6 col-sm-6 mt-4 mb-4">

            <form action="<?php echo e(route('import')); ?>" method="post" enctype="multipart/form-data">
                <div class="card">
                    <div class="card-header bg-dark text-white">
                        Importar 
                    </div>
                    <div class="card-body">
                        <div class="col-12">

                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <input name="file" type="file" class="custom-file-input" id="file-input">
                                <label class="custom-file-label" for="file-input" data-browse="Procurar">
                                    Procurar
                                </label>
                            </div>

                        </div>
                    </div>
                    <div class="card-footer text-right">
                        <button type="submit" class="btn btn-success">Importar</button>
                    </div>

                </div>

            </form>

        </div>
        <?php else: ?>
        
                <h5 class="mt-5 mb-5 text-center">Você não tem permissão para Exportar e Importar vendas</h5>

                
        <?php endif; ?>

        </div>
        
    </main>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gestao-verde\gestao-verde\resources\views/home.blade.php ENDPATH**/ ?>