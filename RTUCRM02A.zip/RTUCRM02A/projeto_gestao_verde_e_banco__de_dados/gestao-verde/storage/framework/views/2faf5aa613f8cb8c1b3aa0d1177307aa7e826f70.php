
<?php $__env->startSection('title', 'Clientes'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

<div class="card mb-4 mt-4 ">

                <div class="card-header bg-primary">
                    
                   <h3><?php echo e($nclientes); ?> Clientes</h3>
                   
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped " id="dataTable" width="100%" cellspacing="0">
                            <thead>

                                <tr>
                                    <th>Nome</th>
                                    <th>CPF</th>
                                    <th>Celular</th>
                                    <th>E-mail</th>
                                    <th>Endereço</th>
                                    <?php if(auth()->user()->nivel_id == '1'): ?>
                                    <th>Ação</th>
                                    <?php endif; ?>
                                    

                                </tr>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($cliente->nome); ?></td>
                                        <td><?php echo e($cliente->cpf); ?></td>
                                        <td><?php echo e($cliente->telefone); ?></td>
                                        <td><?php echo e($cliente->email); ?></td>
                                        <td width="250"><span class="font-5 "><?php echo e($cliente->cidade); ?>, <?php echo e($cliente->bairro); ?>, <?php echo e($cliente->rua); ?>, <?php echo e($cliente->numero); ?> - CEP <?php echo e($cliente->cep); ?></span></td>
                                        <?php if(auth()->user()->nivel_id == '1'): ?>
                                        <td>
                            <form action="<?php echo e(route('cliente.destroy', $cliente->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                                <button class="btn btn-danger " type="submit">APAGAR</button>
                            </form>
                        </td>
                        <?php endif; ?>
                        
                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if(count($clientes)==0): ?>
                                    <tr>
                                        <td colspan=100> <p class="text-muted text-center ">Não existe nenhum cliente</p></td>
                                    </tr>
                                    <?php endif; ?>
                            </tbody>
                        </table>
                        <?php echo e($pagCliente->links()); ?>

                    </div>
                </div>
            </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gestao-verde\gestao-verde\resources\views/clientes.blade.php ENDPATH**/ ?>