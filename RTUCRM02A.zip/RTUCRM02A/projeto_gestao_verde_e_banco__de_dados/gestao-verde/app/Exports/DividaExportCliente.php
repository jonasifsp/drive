<?php

namespace App\Exports;

use App\Models\Divida;
use Maatwebsite\Excel\Concerns\FromCollection;

class DividaExportCliente implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    protected $id;
    public function __construct($id)
    {
        $this->id = ($id);
    }
    public function collection()
    {    
        $div = Divida::select('id', 'valor', 'data', 'created_at', 'updated_at', 'cliente_id', 'status');
        $div = $div->where('cliente_id', '=', $this->id);
        
        return $div->get();
    }
}
