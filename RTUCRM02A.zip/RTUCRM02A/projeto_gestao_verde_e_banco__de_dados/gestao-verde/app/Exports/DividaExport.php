<?php

namespace App\Exports;

use App\Models\Divida;
use Maatwebsite\Excel\Concerns\FromCollection;

class DividaExport implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return Divida::all();
    }
}
