<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cliente;
use App\Models\Divida;
use App\Anotacao;
use App\Exports\DividaExport;
use App\Imports\DividaImport;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\DividaExportCliente;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $notas = Anotacao::all();
        $dividas = Divida::all();
        $clientes = Cliente::all();

        $nclientes  = Cliente::count();
        $ndividas  = Divida::count();
            
        $pag = $dividas = Divida::paginate(10);
        $dataAtual =  Date('Y-m-d');
        $divAtraso = Divida::all();
        $divDia = Divida::all();
        $divAtraso = count($divAtraso->where('status', '=', 'Em Atraso'));
        
        

        $divDia = $divDia->where('data', '=', $dataAtual);
        $divDia = count($divDia);


        $divAberto = Divida::all();
        
        $divAberto = count($divAberto->where('status', '=', 'Em aberto'));
        
    


        $totaldinrec = Divida::where('status','Pago')-> sum('valor');
        $totaldinareceber = Divida::where('status','Em aberto')-> sum('valor');
        $totaldiatrasado = Divida::where('status','Em atraso')-> sum('valor');
      
        return view('home', compact('clientes', 'notas', 'dividas','nclientes','ndividas','pag','divAtraso','divDia','totaldinrec','totaldinareceber','totaldiatrasado','divAberto'));
    }

    public function export()
    {
        return Excel::download(new DividaExport, 'vendas.xlsx');
        
    }

    public function exportCliente(Request $request)
    {
     // return $request->all();
        try {
            
            
            
         
            if($request->id==0){
                return back()->with('error', 'Selecione um cliente para exportar');
            }
            
            $cliente = Cliente::find($request->id);
            $clienteNome = $cliente->nome;
             return Excel::download(new DividaExportCliente($request->id), $clienteNome.'_vendas.xlsx');

           
        
        } catch (\Exception $ex) {
            return back()->with('error', 'Erro ao tentar exportar o arquivo.');
        }
    }
   
    /**
    * @return \Illuminate\Support\Collection
    */
    public function import()
    {
       
        try {
            $success = Excel::import(new DividaImport, request()->file('file'));
            if ($success) {
                return back()->with('success', 'Arquivo importado com sucesso');
            }
            return back()->with('error', 'Erro ao tentar importar o arquivo. err:'. $success);
        } catch (\Exception $ex) {
            return back()->with('error', 'Erro ao importar, o arquivo não foi selecionado ou é incompatível ');
        }
    }
}
