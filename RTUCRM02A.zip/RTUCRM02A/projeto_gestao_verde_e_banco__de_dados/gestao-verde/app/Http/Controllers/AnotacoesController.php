<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Anotacao;
use Illuminate\Support\Facades\Auth;

class AnotacoesController extends Controller
{
    public function show()
    {
        $notas= Anotacao::all();
        return view('anotacoes.index', compact("notas"));
    }

    public function store(Request $request)
    {

        try{

         $anotacao = new Anotacao();
         $anotacao->title = $request->titulo;
         
         $anotacao->descricao = $request->descricao;
         $anotacao->user_id= auth::user()->id;
         $anotacao->save();
            return "Anotação Cadastrada";
        } catch (\Exception $e) {
            return $e->getMessage();
        }
      
     
    }

    public function delete(Request $request)
    {
        try {
            $nota = Anotacao::find($request->id);
            if (!is_null($nota)||!empty($nota)) {
                $nota->delete();
                return "Excluido com sucesso";
            }
            return "Não encontrado.";
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }
}
