<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Divida;

class RelatorioController extends Controller
{
    public function show()
    {
        $dataAtual =  Date('Y-m-d h:m:s');
        $dividasPagas = Divida::where('status','Pago')->get();
       
        $totaldinrec = Divida::where('status','Pago')-> sum('valor');
        $totaldinareceber = Divida::where('status','Em aberto')-> sum('valor');
        $totaldiatrasado = Divida::where('status','Em atraso')-> sum('valor');


        $emAtraso = Divida::where('data','<', $dataAtual)->where('status' ,'<>','Pago')->get();
        foreach($emAtraso  as $divida){
            if($dataAtual> $divida->data){
                $divida->status = "Em Atraso";
                $divida->save();
            }
        }

        $emAberto = Divida::where('data','>', $dataAtual)->where('status' ,'<>','Pago')->get();
        
        

        return view('relatorios.index', compact('emAtraso','dividasPagas','totaldinrec','totaldinareceber','totaldiatrasado','emAberto'));
    }
}
