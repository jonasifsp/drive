<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cliente;


class clientesController extends Controller
{
    public function index()
    {
       
        $clientes = Cliente::all();

        $nclientes  = Cliente::count();
        
            
      
        $pagCliente =  $clientes = Cliente::paginate(10);


        return view('clientes', compact('clientes','nclientes','pagCliente'));
    }

}
