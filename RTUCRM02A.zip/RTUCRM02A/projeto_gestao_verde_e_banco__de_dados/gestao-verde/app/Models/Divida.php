<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Divida extends Model
{
    use SoftDeletes;
    protected $table = "dividas";
    protected $fillable = ["valor", "data", "cliente_id", "status" ];
    protected $dates =['delete_at'];


    public function cliente(){
        return $this->belongsTo("App\Models\Cliente");

    }
}
