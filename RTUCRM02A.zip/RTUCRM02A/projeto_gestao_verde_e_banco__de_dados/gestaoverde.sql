-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 15-Mar-2021 às 10:22
-- Versão do servidor: 10.1.37-MariaDB
-- versão do PHP: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gestaoverde`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `anotacao`
--

CREATE TABLE `anotacao` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `anotacao`
--

INSERT INTO `anotacao` (`id`, `title`, `descricao`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'Comprar café', 'comprar café no mercado', 1, '2021-03-15 11:16:53', '2021-03-15 11:16:53'),
(2, 'Pagar conta de luz', 'pagar conta de luz dia 5', 1, '2021-03-15 11:17:46', '2021-03-15 11:17:46'),
(4, 'Ligar para clientes', 'ligar para oferecer promoção', 1, '2021-03-15 11:19:15', '2021-03-15 11:19:15'),
(5, 'Atualizar', 'informações de clientes', 1, '2021-03-15 11:38:11', '2021-03-15 11:38:11');

-- --------------------------------------------------------

--
-- Estrutura da tabela `clientes`
--

CREATE TABLE `clientes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cpf` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rua` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bairro` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cep` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `clientes`
--

INSERT INTO `clientes` (`id`, `nome`, `email`, `cpf`, `telefone`, `rua`, `bairro`, `cidade`, `numero`, `cep`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Aldair Miguel', 'aldarimiguel@aldair.com', '343.543.566-54', '(12) 98906-5808', 'rua Treze', 'Jaraguá', 'Caraguatatuba', '77', '11662-553', '2021-03-15 11:16:13', '2021-03-15 11:16:13', NULL),
(2, 'João Pedro', 'jp@jaopedro.com', '734.672.364-82', '(12) 90889-8698', 'rua Miguel varlez', 'Centro', 'Caraguatatuba', '23', '11668487', '2021-03-15 11:20:50', '2021-03-15 11:20:50', NULL),
(3, 'Ana Maria', 'anamaria@ana.com', '732.896.472-64', '(12) 99673-5424', 'rua Luna Mar', 'Porto Novo', 'Caraguatatuba', '67', '11667289', '2021-03-15 11:21:55', '2021-03-15 11:21:55', NULL),
(4, 'Camile Oliveira', 'camileoliveira@oli.com', '723.647.862-38', '(12) 99873-9478', 'rua Tubarão', 'Golfinho', 'Caraguatatuba', '289', '11668293', '2021-03-15 11:22:57', '2021-03-15 11:22:57', NULL),
(5, 'José Perreira', 'josep@j.com', '871.263.786-38', '(12) 99923-8482', 'rua Capitão nascimento', 'Perequê-Mirim', 'Caraguatatuba', '34', '11668092', '2021-03-15 11:24:07', '2021-03-15 11:24:07', NULL),
(6, 'Caroline Ferreira', 'carolsff@ff.com', '293.472.749-27', '(12) 99984-3328', 'rua Mar aberto', 'Praia das Palmeiras', 'Caraguatatuba', '30', '11666772', '2021-03-15 11:25:09', '2021-03-15 11:25:09', NULL),
(7, 'Aninha Juliana', 'aninhaju@ju.com', '178.436.812-74', '(12) 99284-7834', 'rua Odisel', 'Enseada', 'São Sebastião', '90', '11668781', '2021-03-15 11:26:22', '2021-03-15 11:26:22', NULL),
(8, 'Pedro João', 'pedroj@pj.com', '239.784.987-32', '(12) 83479-7823', 'rua Brasil', 'Indaia', 'Caraguatatuba', '44', '11669283', '2021-03-15 11:27:29', '2021-03-15 11:27:29', NULL),
(9, 'Izabelle Carol', 'izacarol@col.com', '374.678.648-72', '(12) 92839-8478', 'rua São pedro', 'Jaraguá', 'Caraguatatuba', '678', '11668376', '2021-03-15 11:29:32', '2021-03-15 11:29:32', NULL),
(10, 'Julio Cesar', 'jucesar@ju.com', '178.294.367-12', '(12) 99787-3289', 'rua Juazeiro', 'Prainha', 'Ubatuba', '90', '11667298', '2021-03-15 11:30:35', '2021-03-15 11:30:35', NULL),
(11, 'Julia Costa', 'julianacosta@ju.com', '397.482.349-23', '(12) 99387-6426', 'rua Camile ferraz', 'Centro', 'Ilhabela', '839', '11669283', '2021-03-15 11:31:45', '2021-03-15 11:31:45', NULL),
(12, 'Rodolfo Afonso', 'rodolfoafon@afon.com', '893.748.974-98', '(12) 99483-4897', 'rua São luis', 'Centro', 'Caraguatatuba', '88', '11667878', '2021-03-15 11:33:18', '2021-03-15 11:33:18', NULL),
(13, 'Gilberto Atenor', 'gilat@at.com', '398.479.328-74', '(12) 93848-9739', 'rua Julie sandra', 'Centro', 'Ubatuba', '988', '11668939', '2021-03-15 11:34:36', '2021-03-15 11:34:36', NULL),
(14, 'Thiago livia', 'thiagolivi@livi.com', '478.714.913-87', '(12) 38974-9789', 'av Miguel varlez', 'Martim de sá', 'Caraguatatuba', '46', '11667387', '2021-03-15 11:35:52', '2021-03-15 11:35:52', NULL),
(15, 'Iza Oliveira', 'izaoliv@oliv.com', '289.374.893-27', '(12) 89378-4729', 'rua Izac', 'Canto do mar', 'São Sebastião', '83', '11662897', '2021-03-15 11:37:15', '2021-03-15 11:37:15', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `dividas`
--

CREATE TABLE `dividas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `valor` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `cliente_id` bigint(20) UNSIGNED NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `dividas`
--

INSERT INTO `dividas` (`id`, `valor`, `data`, `created_at`, `updated_at`, `cliente_id`, `status`, `deleted_at`) VALUES
(1, '10,00', '2021-03-30', '2021-03-15 11:42:23', '2021-03-15 11:42:23', 1, 'Em aberto', NULL),
(2, '15,00', '2021-03-31', '2021-03-15 11:43:36', '2021-03-15 11:43:36', 2, 'Em aberto', NULL),
(3, '60,00', '2021-03-23', '2021-03-15 11:44:19', '2021-03-15 11:44:19', 3, 'Em aberto', NULL),
(4, '55,00', '2021-03-28', '2021-03-15 11:44:36', '2021-03-15 11:49:50', 5, 'Pago', NULL),
(5, '50,00', '2021-03-28', '2021-03-15 11:45:03', '2021-03-15 11:45:03', 4, 'Em aberto', NULL),
(6, '36,00', '2021-03-21', '2021-03-15 11:45:23', '2021-03-15 11:45:23', 15, 'Em aberto', NULL),
(7, '5,00', '2021-03-27', '2021-03-15 11:45:52', '2021-03-15 11:45:52', 14, 'Em aberto', NULL),
(8, '69,00', '2021-03-29', '2021-03-15 11:46:12', '2021-03-15 11:55:37', 13, 'Pago', NULL),
(9, '33,00', '2021-03-29', '2021-03-15 11:49:10', '2021-03-15 11:49:10', 9, 'Em aberto', NULL),
(10, '99,00', '2021-03-01', '2021-03-15 11:49:36', '2021-03-15 11:53:13', 8, 'Em Atraso', NULL),
(11, '67,00', '2021-03-24', '2021-03-15 11:50:08', '2021-03-15 11:50:08', 8, 'Em aberto', NULL),
(12, '99,00', '2021-03-23', '2021-03-15 11:50:49', '2021-03-15 11:50:49', 8, 'Em aberto', NULL),
(13, '80', '2021-03-17', '2021-03-15 11:51:04', '2021-03-15 11:51:04', 7, 'Em aberto', NULL),
(14, '89', '2021-03-18', '2021-03-15 11:51:42', '2021-03-15 11:51:42', 12, 'Em aberto', NULL),
(15, '57,00', '2021-03-20', '2021-03-15 11:52:57', '2021-03-15 11:52:57', 5, 'Em aberto', NULL),
(16, '88,00', '2021-03-14', '2021-03-15 11:54:26', '2021-03-15 11:54:51', 4, 'Em Atraso', NULL),
(17, '89,00', '2021-03-24', '2021-03-15 12:00:06', '2021-03-15 12:00:06', 4, 'Em aberto', NULL),
(18, '50,00', '2021-03-18', '2021-03-15 12:01:41', '2021-03-15 12:01:41', 8, 'Em aberto', NULL),
(19, '100,00', '2021-03-11', '2021-03-15 12:10:37', '2021-03-15 12:10:56', 7, 'Em Atraso', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(64, '2013_01_19_182909_nivel', 1),
(65, '2014_10_12_000000_create_users_table', 1),
(66, '2014_10_12_100000_create_password_resets_table', 1),
(67, '2019_08_19_000000_create_failed_jobs_table', 1),
(68, '2021_01_18_184603_clientes', 1),
(69, '2021_01_19_183455_dividas', 1),
(70, '2021_02_08_202613_anotacao', 1),
(71, '2021_03_14_154059_add_soft_deletes_to_dividas_table', 1),
(72, '2021_03_15_000757_add_fot_deletes_to_clientes_table', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `nivel`
--

CREATE TABLE `nivel` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `nivel_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `nivel_id`) VALUES
(1, 'Jonas Oliveira', 'jonas@jonas.com', NULL, '$2y$10$5HVbX8dRbFP2rDGrVIr62uUdDSrqJGtS62BekOgST2XM8LFZTZLTe', NULL, '2021-03-15 11:11:44', '2021-03-15 11:11:44', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `anotacao`
--
ALTER TABLE `anotacao`
  ADD PRIMARY KEY (`id`),
  ADD KEY `anotacao_user_id_foreign` (`user_id`);

--
-- Indexes for table `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dividas`
--
ALTER TABLE `dividas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dividas_cliente_id_foreign` (`cliente_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nivel`
--
ALTER TABLE `nivel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `anotacao`
--
ALTER TABLE `anotacao`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `dividas`
--
ALTER TABLE `dividas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `nivel`
--
ALTER TABLE `nivel`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `anotacao`
--
ALTER TABLE `anotacao`
  ADD CONSTRAINT `anotacao_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Limitadores para a tabela `dividas`
--
ALTER TABLE `dividas`
  ADD CONSTRAINT `dividas_cliente_id_foreign` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
